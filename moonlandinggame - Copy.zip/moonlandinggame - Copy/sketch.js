var START = 0;
var PLAY = 1;
var END = 2;
var gameState = START;
var bg,backgroundImage
var rocket,rocketImage
var asteroid,asteroidImage
var moon,moonImage
var missileImage,missile
var powerUp,powerUpImage
var score = 0;

function preload(){
backgroundImage = loadImage('background.png')
rocketImage = loadImage('rocket.png')
asteroidImage = loadImage('Asteroid.png')
}
function setup(){
createCanvas(1300,700)

bg = createSprite(650,350,1300,700)
bg.addImage(backgroundImage)
bg.scale = 3
bg.y = bg.width/2
rocket = createSprite(630,550,20,20)
rocket.addImage(rocketImage)
rocket.scale = 0.05 
missileGroup = new Group()
asteroidGroup = new Group()
}
function draw(){
  background(0);
  drawSprites();

  textFont("bold");
  textSize(20)
  fill("white");
  text("Score: "+score,1100,30);
  if(bg.y>500){
    bg.y = 600;
  }
  if(gameState === START){
    
    console.log("gameState start")
    text("PRESS SPACE TO START",600,300);
    if(keyDown("UP_ARROW")){
      gameState = PLAY;
    }

  }
  if(gameState === PLAY){
    
        spawnAsteroids();
        console.log("gameState play")
        if(keyDown("LEFT_ARROW")){
          rocket.x = rocket.x+-2;
        }
        if(keyDown("RIGHT_ARROW")){
          rocket.x = rocket.x+2;
        }
        bg.velocityY = 2
        if(keyDown("space")){
          launchMissile()
        }
        for(var i = 0;i<asteroidGroup.length;i++){
          if(asteroidGroup.get(i).isTouching(missileGroup)){
            asteroidGroup.get(i).destroy();
            missileGroup.destroyEach();
            score = score+1;
          }
        
        }

        if(asteroidGroup.isTouching(rocket)){
          gameState = END
        }
  }
  else if(gameState === END){
  asteroidGroup.setVelocityYEach(0);



  }
  
}
function spawnAsteroids(){

if(frameCount%20 === 0)
{var x = Math.round(random(0,1300))
  var y = Math.round(random(-20,-10))
  asteroid = createSprite(x,y,50,50)
  asteroid.addImage(asteroidImage)
  asteroid.scale = 0.1
  asteroid.velocityY = 2

  asteroidGroup.add(asteroid)
}
}
function launchMissile(){
  var missile = createSprite(rocket.x,rocket.y,10,50)
  missile.y = rocket.y;
  missile.velocityY = -4
  missile.lifetime = 500
  missileGroup.add(missile)

}
